from django.apps import AppConfig


class BloodAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'blood_app'
